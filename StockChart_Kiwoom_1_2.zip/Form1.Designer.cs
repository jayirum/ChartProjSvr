﻿namespace TTN
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.favordeleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realsaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realTextSaveGoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.nowsaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelsaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dbsaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kiwoomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.mycodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gurewonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allcodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.conditionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockmainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView_upper = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pan_forin = new System.Windows.Forms.Panel();
            this.pan_mesu = new System.Windows.Forms.Panel();
            this.pan_medo = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtRealData = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.btnNowVal = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();
            this.comBuySellType = new System.Windows.Forms.ComboBox();
            this.comOderType = new System.Windows.Forms.ComboBox();
            this.txtOriginalOdernumber = new System.Windows.Forms.TextBox();
            this.txtOrderPay = new System.Windows.Forms.TextBox();
            this.txtOrderCounts = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comAccounts = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.hHippoChart1 = new Hippo.WindowsForm4.hHippoChart();
            this.panel7 = new System.Windows.Forms.Panel();
            this.chkStochastic = new System.Windows.Forms.CheckBox();
            this.chkRSI = new System.Windows.Forms.CheckBox();
            this.chkILMOK = new System.Windows.Forms.CheckBox();
            this.chkOSC = new System.Windows.Forms.CheckBox();
            this.chkSR3 = new System.Windows.Forms.CheckBox();
            this.chkSR2 = new System.Windows.Forms.CheckBox();
            this.chkBB = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.chkSR1 = new System.Windows.Forms.CheckBox();
            this.chkSR0 = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TSL_status = new System.Windows.Forms.Label();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.la_codeName = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3_code = new System.Windows.Forms.ToolStripLabel();
            this.la_currentVal = new System.Windows.Forms.ToolStripLabel();
            this.laupdawon = new System.Windows.Forms.ToolStripLabel();
            this.la_volume = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.TSBday = new System.Windows.Forms.ToolStripButton();
            this.TSBweek = new System.Windows.Forms.ToolStripButton();
            this.TSBmonth = new System.Windows.Forms.ToolStripButton();
            this.TSBmin = new System.Windows.Forms.ToolStripButton();
            this.TSBtick = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.TSL_su_1 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_3 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_5 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_10 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_30 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_60 = new System.Windows.Forms.ToolStripButton();
            this.TSL_su_120 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.TSL_btnNext = new System.Windows.Forms.ToolStripButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelLogin = new System.Windows.Forms.ToolStripStatusLabel();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_upper)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.chartToolStripMenuItem,
            this.dataToolStripMenuItem,
            this.kiwoomToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1143, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.favordeleToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.fileToolStripMenuItem.Text = "파일";
            // 
            // favordeleToolStripMenuItem
            // 
            this.favordeleToolStripMenuItem.Name = "favordeleToolStripMenuItem";
            this.favordeleToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.favordeleToolStripMenuItem.Text = "관심종목 전체삭제";
            this.favordeleToolStripMenuItem.Click += new System.EventHandler(this.favordeleToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(171, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.exitToolStripMenuItem.Text = "프로그램 종료";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // chartToolStripMenuItem
            // 
            this.chartToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("chartToolStripMenuItem.Image")));
            this.chartToolStripMenuItem.Name = "chartToolStripMenuItem";
            this.chartToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.chartToolStripMenuItem.Text = "차트";
            // 
            // dataToolStripMenuItem
            // 
            this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.realsaveToolStripMenuItem,
            this.realTextSaveGoToolStripMenuItem,
            this.toolStripMenuItem3,
            this.nowsaveToolStripMenuItem,
            this.excelsaveToolStripMenuItem,
            this.dbsaveToolStripMenuItem});
            this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
            this.dataToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.dataToolStripMenuItem.Text = "데이터";
            // 
            // realsaveToolStripMenuItem
            // 
            this.realsaveToolStripMenuItem.Name = "realsaveToolStripMenuItem";
            this.realsaveToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.realsaveToolStripMenuItem.Text = "실시간 데이터 저장 시작";
            this.realsaveToolStripMenuItem.Click += new System.EventHandler(this.realsaveToolStripMenuItem_Click);
            // 
            // realTextSaveGoToolStripMenuItem
            // 
            this.realTextSaveGoToolStripMenuItem.Name = "realTextSaveGoToolStripMenuItem";
            this.realTextSaveGoToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.realTextSaveGoToolStripMenuItem.Text = "저장된 실시간 데이터 파일 저장";
            this.realTextSaveGoToolStripMenuItem.Click += new System.EventHandler(this.realTextSaveGoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(243, 6);
            // 
            // nowsaveToolStripMenuItem
            // 
            this.nowsaveToolStripMenuItem.Name = "nowsaveToolStripMenuItem";
            this.nowsaveToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.nowsaveToolStripMenuItem.Text = "현재 데이터 저장(봉데이터)";
            this.nowsaveToolStripMenuItem.Click += new System.EventHandler(this.nowsaveToolStripMenuItem_Click);
            // 
            // excelsaveToolStripMenuItem
            // 
            this.excelsaveToolStripMenuItem.ForeColor = System.Drawing.Color.Green;
            this.excelsaveToolStripMenuItem.Name = "excelsaveToolStripMenuItem";
            this.excelsaveToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.excelsaveToolStripMenuItem.Text = "CSV로 저장";
            this.excelsaveToolStripMenuItem.Click += new System.EventHandler(this.excelsaveToolStripMenuItem_Click);
            // 
            // dbsaveToolStripMenuItem
            // 
            this.dbsaveToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.dbsaveToolStripMenuItem.Name = "dbsaveToolStripMenuItem";
            this.dbsaveToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.dbsaveToolStripMenuItem.Text = "DB 저장";
            this.dbsaveToolStripMenuItem.Click += new System.EventHandler(this.dbsaveToolStripMenuItem_Click);
            // 
            // kiwoomToolStripMenuItem
            // 
            this.kiwoomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.toolStripMenuItem4,
            this.mycodeToolStripMenuItem,
            this.accountToolStripMenuItem,
            this.gurewonToolStripMenuItem,
            this.allcodeToolStripMenuItem,
            this.toolStripMenuItem5,
            this.conditionToolStripMenuItem,
            this.toolStripMenuItem1,
            this.logoutToolStripMenuItem});
            this.kiwoomToolStripMenuItem.Name = "kiwoomToolStripMenuItem";
            this.kiwoomToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.kiwoomToolStripMenuItem.Text = "키움증권";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.loginToolStripMenuItem.Text = "로그인";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(139, 6);
            // 
            // mycodeToolStripMenuItem
            // 
            this.mycodeToolStripMenuItem.Name = "mycodeToolStripMenuItem";
            this.mycodeToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.mycodeToolStripMenuItem.Text = "보유 종목";
            // 
            // accountToolStripMenuItem
            // 
            this.accountToolStripMenuItem.Name = "accountToolStripMenuItem";
            this.accountToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.accountToolStripMenuItem.Text = "계좌 조회";
            this.accountToolStripMenuItem.Click += new System.EventHandler(this.accountToolStripMenuItem_Click);
            // 
            // gurewonToolStripMenuItem
            // 
            this.gurewonToolStripMenuItem.Name = "gurewonToolStripMenuItem";
            this.gurewonToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.gurewonToolStripMenuItem.Text = "거래원";
            this.gurewonToolStripMenuItem.Click += new System.EventHandler(this.gurewonToolStripMenuItem_Click);
            // 
            // allcodeToolStripMenuItem
            // 
            this.allcodeToolStripMenuItem.Name = "allcodeToolStripMenuItem";
            this.allcodeToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.allcodeToolStripMenuItem.Text = "전 종목 조회";
            this.allcodeToolStripMenuItem.Click += new System.EventHandler(this.allcodeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(139, 6);
            // 
            // conditionToolStripMenuItem
            // 
            this.conditionToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.conditionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("conditionToolStripMenuItem.Image")));
            this.conditionToolStripMenuItem.Name = "conditionToolStripMenuItem";
            this.conditionToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.conditionToolStripMenuItem.Text = "조건검색";
            this.conditionToolStripMenuItem.Click += new System.EventHandler(this.conditionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(139, 6);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.logoutToolStripMenuItem.Text = "로그아웃";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.duceToolStripMenuItem,
            this.toolStripMenuItem6,
            this.infoToolStripMenuItem,
            this.stockmainToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.helpToolStripMenuItem.Text = "도움말";
            // 
            // duceToolStripMenuItem
            // 
            this.duceToolStripMenuItem.Name = "duceToolStripMenuItem";
            this.duceToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.duceToolStripMenuItem.Text = "프로그램 소개";
            this.duceToolStripMenuItem.Click += new System.EventHandler(this.duceToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(159, 6);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("infoToolStripMenuItem.Image")));
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.infoToolStripMenuItem.Text = "히포차트";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // stockmainToolStripMenuItem
            // 
            this.stockmainToolStripMenuItem.Name = "stockmainToolStripMenuItem";
            this.stockmainToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.stockmainToolStripMenuItem.Text = "증권페이지 메인";
            this.stockmainToolStripMenuItem.Click += new System.EventHandler(this.stockmainToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel3);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(1143, 617);
            this.splitContainer1.SplitterDistance = 248;
            this.splitContainer1.TabIndex = 1;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(0, 0);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(248, 617);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Controls.Add(this.dataGridView_upper);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(240, 588);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "관심종목";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 127);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(240, 461);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(127, 26);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.deleteToolStripMenuItem.Text = "종목 삭제";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // dataGridView_upper
            // 
            this.dataGridView_upper.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView_upper.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_upper.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView_upper.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView_upper.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_upper.Name = "dataGridView_upper";
            this.dataGridView_upper.ReadOnly = true;
            this.dataGridView_upper.RowTemplate.Height = 23;
            this.dataGridView_upper.Size = new System.Drawing.Size(240, 127);
            this.dataGridView_upper.TabIndex = 1;
            this.dataGridView_upper.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_upper_CellContentDoubleClick);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.pan_forin);
            this.tabPage1.Controls.Add(this.pan_mesu);
            this.tabPage1.Controls.Add(this.pan_medo);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.txtRealData);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.txtCode);
            this.tabPage1.Controls.Add(this.btnNowVal);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(240, 588);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "현재가";
            // 
            // pan_forin
            // 
            this.pan_forin.BackColor = System.Drawing.Color.AliceBlue;
            this.pan_forin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pan_forin.Location = new System.Drawing.Point(15, 532);
            this.pan_forin.Name = "pan_forin";
            this.pan_forin.Size = new System.Drawing.Size(211, 40);
            this.pan_forin.TabIndex = 38;
            // 
            // pan_mesu
            // 
            this.pan_mesu.AutoScroll = true;
            this.pan_mesu.BackColor = System.Drawing.Color.LavenderBlush;
            this.pan_mesu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pan_mesu.Location = new System.Drawing.Point(16, 410);
            this.pan_mesu.Name = "pan_mesu";
            this.pan_mesu.Size = new System.Drawing.Size(210, 121);
            this.pan_mesu.TabIndex = 37;
            // 
            // pan_medo
            // 
            this.pan_medo.AutoScroll = true;
            this.pan_medo.BackColor = System.Drawing.Color.AliceBlue;
            this.pan_medo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pan_medo.Location = new System.Drawing.Point(16, 285);
            this.pan_medo.Name = "pan_medo";
            this.pan_medo.Size = new System.Drawing.Size(210, 124);
            this.pan_medo.TabIndex = 36;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(84, 50);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(129, 21);
            this.dateTimePicker1.TabIndex = 35;
            // 
            // txtRealData
            // 
            this.txtRealData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRealData.BackColor = System.Drawing.Color.White;
            this.txtRealData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRealData.Enabled = false;
            this.txtRealData.ForeColor = System.Drawing.Color.White;
            this.txtRealData.Location = new System.Drawing.Point(16, 77);
            this.txtRealData.Multiline = true;
            this.txtRealData.Name = "txtRealData";
            this.txtRealData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRealData.Size = new System.Drawing.Size(210, 202);
            this.txtRealData.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(14, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 12);
            this.label13.TabIndex = 30;
            this.label13.Text = "종목코드 :";
            // 
            // txtCode
            // 
            this.txtCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCode.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCode.Location = new System.Drawing.Point(84, 20);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(81, 24);
            this.txtCode.TabIndex = 31;
            this.txtCode.Text = "066910";
            // 
            // btnNowVal
            // 
            this.btnNowVal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNowVal.ForeColor = System.Drawing.Color.Black;
            this.btnNowVal.Location = new System.Drawing.Point(171, 20);
            this.btnNowVal.Name = "btnNowVal";
            this.btnNowVal.Size = new System.Drawing.Size(55, 24);
            this.btnNowVal.TabIndex = 32;
            this.btnNowVal.Text = "조회";
            this.btnNowVal.UseVisualStyleBackColor = true;
            this.btnNowVal.Click += new System.EventHandler(this.btnNowVal_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(67)))), ((int)(((byte)(67)))));
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.comAccounts);
            this.tabPage2.ForeColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(240, 588);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "주문";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btnOrder);
            this.groupBox1.Controls.Add(this.comBuySellType);
            this.groupBox1.Controls.Add(this.comOderType);
            this.groupBox1.Controls.Add(this.txtOriginalOdernumber);
            this.groupBox1.Controls.Add(this.txtOrderPay);
            this.groupBox1.Controls.Add(this.txtOrderCounts);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(19, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 323);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "주문입력";
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("굴림", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button4.ForeColor = System.Drawing.Color.OrangeRed;
            this.button4.Location = new System.Drawing.Point(154, 191);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(28, 24);
            this.button4.TabIndex = 36;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("굴림", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.button3.Location = new System.Drawing.Point(94, 191);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 24);
            this.button3.TabIndex = 35;
            this.button3.Text = "-";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(145, 122);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 24);
            this.button2.TabIndex = 34;
            this.button2.Text = "최대";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(95, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 24);
            this.button1.TabIndex = 33;
            this.button1.Text = "금액";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnOrder
            // 
            this.btnOrder.ForeColor = System.Drawing.Color.Black;
            this.btnOrder.Location = new System.Drawing.Point(20, 277);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(164, 30);
            this.btnOrder.TabIndex = 12;
            this.btnOrder.Text = "주문";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnORDER_GOGO_Click);
            // 
            // comBuySellType
            // 
            this.comBuySellType.FormattingEnabled = true;
            this.comBuySellType.Location = new System.Drawing.Point(95, 62);
            this.comBuySellType.Name = "comBuySellType";
            this.comBuySellType.Size = new System.Drawing.Size(89, 20);
            this.comBuySellType.TabIndex = 11;
            // 
            // comOderType
            // 
            this.comOderType.FormattingEnabled = true;
            this.comOderType.Location = new System.Drawing.Point(95, 31);
            this.comOderType.Name = "comOderType";
            this.comOderType.Size = new System.Drawing.Size(89, 20);
            this.comOderType.TabIndex = 10;
            // 
            // txtOriginalOdernumber
            // 
            this.txtOriginalOdernumber.Location = new System.Drawing.Point(93, 236);
            this.txtOriginalOdernumber.Name = "txtOriginalOdernumber";
            this.txtOriginalOdernumber.Size = new System.Drawing.Size(89, 21);
            this.txtOriginalOdernumber.TabIndex = 9;
            // 
            // txtOrderPay
            // 
            this.txtOrderPay.Location = new System.Drawing.Point(93, 164);
            this.txtOrderPay.Name = "txtOrderPay";
            this.txtOrderPay.Size = new System.Drawing.Size(91, 21);
            this.txtOrderPay.TabIndex = 8;
            this.txtOrderPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtOrderCounts
            // 
            this.txtOrderCounts.Location = new System.Drawing.Point(95, 91);
            this.txtOrderCounts.Name = "txtOrderCounts";
            this.txtOrderCounts.Size = new System.Drawing.Size(89, 21);
            this.txtOrderCounts.TabIndex = 7;
            this.txtOrderCounts.Text = "1";
            this.txtOrderCounts.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(18, 239);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 5;
            this.label11.Text = "원주문번호";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(30, 167);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "주문가격";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(32, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "주문수량";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(32, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "매매구분";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(32, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "거래구분";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(17, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "내 계좌 : ";
            // 
            // comAccounts
            // 
            this.comAccounts.FormattingEnabled = true;
            this.comAccounts.Location = new System.Drawing.Point(80, 18);
            this.comAccounts.Name = "comAccounts";
            this.comAccounts.Size = new System.Drawing.Size(136, 20);
            this.comAccounts.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 25);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(2);
            this.panel3.Size = new System.Drawing.Size(891, 567);
            this.panel3.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.hHippoChart1);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(2, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(887, 538);
            this.panel5.TabIndex = 2;
            // 
            // hHippoChart1
            // 
            this.hHippoChart1.BackColor = System.Drawing.Color.Transparent;
            this.hHippoChart1.ChartGraphic = null;
            this.hHippoChart1.ChartID = null;
            this.hHippoChart1.ChartImage = null;
            this.hHippoChart1.ChartRectangle = ((System.Drawing.RectangleF)(resources.GetObject("hHippoChart1.ChartRectangle")));
            this.hHippoChart1.Designer = ((Hippo.ChartDesigner)(resources.GetObject("hHippoChart1.Designer")));
            this.hHippoChart1.DesignType = Hippo.ChartDesignType.None;
            this.hHippoChart1.Direction = Hippo.GraphAreaLocation.Vertical;
            this.hHippoChart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hHippoChart1.Height2 = 270F;
            this.hHippoChart1.IsDrag = false;
            this.hHippoChart1.IsEmptyanalysis = true;
            this.hHippoChart1.IsUseContextMenu = true;
            this.hHippoChart1.Layout = ((Hippo.Layout)(resources.GetObject("hHippoChart1.Layout")));
            this.hHippoChart1.Left = 0F;
            this.hHippoChart1.LegendBox = ((Hippo.LegendBox)(resources.GetObject("hHippoChart1.LegendBox")));
            this.hHippoChart1.Location = new System.Drawing.Point(0, 33);
            this.hHippoChart1.Logo = ((Hippo.Logo)(resources.GetObject("hHippoChart1.Logo")));
            this.hHippoChart1.MinimumSize = new System.Drawing.Size(200, 140);
            this.hHippoChart1.Name = "hHippoChart1";
            this.hHippoChart1.PaletteType = Hippo.PaletteType.Default;
            this.hHippoChart1.ProcessorType = "32";
            this.hHippoChart1.SeriesAreaRate = null;
            this.hHippoChart1.SeriesListDictionary = ((Hippo.SeriesListDictionary)(resources.GetObject("hHippoChart1.SeriesListDictionary")));
            this.hHippoChart1.Size = new System.Drawing.Size(887, 505);
            this.hHippoChart1.TabIndex = 0;
            this.hHippoChart1.Titles = ((Hippo.Title)(resources.GetObject("hHippoChart1.Titles")));
            this.hHippoChart1.Top = 101F;
            this.hHippoChart1.Width2 = 400F;
            this.hHippoChart1.ChartSizeChanged += new System.EventHandler(this.hHippoChart1_ChartSizeChanged_2);
            this.hHippoChart1.ChartMouseMove += new System.Windows.Forms.MouseEventHandler(this.hHippoChart1_ChartMouseMove);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.chkStochastic);
            this.panel7.Controls.Add(this.chkRSI);
            this.panel7.Controls.Add(this.chkILMOK);
            this.panel7.Controls.Add(this.chkOSC);
            this.panel7.Controls.Add(this.chkSR3);
            this.panel7.Controls.Add(this.chkSR2);
            this.panel7.Controls.Add(this.chkBB);
            this.panel7.Controls.Add(this.checkBox3);
            this.panel7.Controls.Add(this.chkSR1);
            this.panel7.Controls.Add(this.chkSR0);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(887, 33);
            this.panel7.TabIndex = 1;
            // 
            // chkStochastic
            // 
            this.chkStochastic.AutoSize = true;
            this.chkStochastic.Location = new System.Drawing.Point(635, 8);
            this.chkStochastic.Name = "chkStochastic";
            this.chkStochastic.Size = new System.Drawing.Size(84, 16);
            this.chkStochastic.TabIndex = 9;
            this.chkStochastic.Text = "스토캐스틱";
            this.chkStochastic.UseVisualStyleBackColor = true;
            this.chkStochastic.CheckedChanged += new System.EventHandler(this.chkStochastic_CheckedChanged);
            // 
            // chkRSI
            // 
            this.chkRSI.AutoSize = true;
            this.chkRSI.Location = new System.Drawing.Point(586, 8);
            this.chkRSI.Name = "chkRSI";
            this.chkRSI.Size = new System.Drawing.Size(43, 16);
            this.chkRSI.TabIndex = 8;
            this.chkRSI.Text = "RSI";
            this.chkRSI.UseVisualStyleBackColor = true;
            this.chkRSI.CheckedChanged += new System.EventHandler(this.chkRSI_CheckedChanged);
            // 
            // chkILMOK
            // 
            this.chkILMOK.AutoSize = true;
            this.chkILMOK.ForeColor = System.Drawing.Color.Blue;
            this.chkILMOK.Location = new System.Drawing.Point(496, 8);
            this.chkILMOK.Name = "chkILMOK";
            this.chkILMOK.Size = new System.Drawing.Size(84, 16);
            this.chkILMOK.TabIndex = 7;
            this.chkILMOK.Text = "일목균형표";
            this.chkILMOK.UseVisualStyleBackColor = true;
            this.chkILMOK.CheckedChanged += new System.EventHandler(this.chkILMOK_CheckedChanged);
            // 
            // chkOSC
            // 
            this.chkOSC.AutoSize = true;
            this.chkOSC.Location = new System.Drawing.Point(346, 8);
            this.chkOSC.Name = "chkOSC";
            this.chkOSC.Size = new System.Drawing.Size(50, 16);
            this.chkOSC.TabIndex = 6;
            this.chkOSC.Text = "OSC";
            this.chkOSC.UseVisualStyleBackColor = true;
            this.chkOSC.CheckedChanged += new System.EventHandler(this.chkOSC_CheckedChanged);
            // 
            // chkSR3
            // 
            this.chkSR3.AutoSize = true;
            this.chkSR3.Checked = true;
            this.chkSR3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSR3.Location = new System.Drawing.Point(213, 8);
            this.chkSR3.Name = "chkSR3";
            this.chkSR3.Size = new System.Drawing.Size(60, 16);
            this.chkSR3.TabIndex = 5;
            this.chkSR3.Text = "60일선";
            this.chkSR3.UseVisualStyleBackColor = true;
            this.chkSR3.CheckedChanged += new System.EventHandler(this.chkSR3_CheckedChanged);
            // 
            // chkSR2
            // 
            this.chkSR2.AutoSize = true;
            this.chkSR2.Checked = true;
            this.chkSR2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSR2.Location = new System.Drawing.Point(145, 8);
            this.chkSR2.Name = "chkSR2";
            this.chkSR2.Size = new System.Drawing.Size(60, 16);
            this.chkSR2.TabIndex = 4;
            this.chkSR2.Text = "20일선";
            this.chkSR2.UseVisualStyleBackColor = true;
            this.chkSR2.CheckedChanged += new System.EventHandler(this.chkSR2_CheckedChanged);
            // 
            // chkBB
            // 
            this.chkBB.AutoSize = true;
            this.chkBB.Location = new System.Drawing.Point(402, 8);
            this.chkBB.Name = "chkBB";
            this.chkBB.Size = new System.Drawing.Size(88, 16);
            this.chkBB.TabIndex = 3;
            this.chkBB.Text = "볼린저 밴드";
            this.chkBB.UseVisualStyleBackColor = true;
            this.chkBB.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(280, 8);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(60, 16);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "MACD";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // chkSR1
            // 
            this.chkSR1.AutoSize = true;
            this.chkSR1.Checked = true;
            this.chkSR1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSR1.Location = new System.Drawing.Point(83, 8);
            this.chkSR1.Name = "chkSR1";
            this.chkSR1.Size = new System.Drawing.Size(54, 16);
            this.chkSR1.TabIndex = 1;
            this.chkSR1.Text = "5일선";
            this.chkSR1.UseVisualStyleBackColor = true;
            this.chkSR1.CheckedChanged += new System.EventHandler(this.chkSR1_CheckedChanged);
            // 
            // chkSR0
            // 
            this.chkSR0.AutoSize = true;
            this.chkSR0.Checked = true;
            this.chkSR0.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSR0.Location = new System.Drawing.Point(5, 8);
            this.chkSR0.Name = "chkSR0";
            this.chkSR0.Size = new System.Drawing.Size(72, 16);
            this.chkSR0.TabIndex = 0;
            this.chkSR0.Text = "주식차트";
            this.chkSR0.UseVisualStyleBackColor = true;
            this.chkSR0.CheckedChanged += new System.EventHandler(this.chkSR0_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.btn_all);
            this.panel6.Controls.Add(this.btn_minus);
            this.panel6.Controls.Add(this.btn_plus);
            this.panel6.Controls.Add(this.trackBar1);
            this.panel6.Controls.Add(this.hScrollBar1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(2, 540);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(887, 25);
            this.panel6.TabIndex = 3;
            // 
            // btn_all
            // 
            this.btn_all.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_all.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_all.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_all.Location = new System.Drawing.Point(860, 2);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(22, 22);
            this.btn_all.TabIndex = 5;
            this.btn_all.Text = "A";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minus.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_minus.Location = new System.Drawing.Point(833, 2);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(22, 22);
            this.btn_minus.TabIndex = 4;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click);
            // 
            // btn_plus
            // 
            this.btn_plus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_plus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_plus.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_plus.Location = new System.Drawing.Point(806, 2);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(22, 22);
            this.btn_plus.TabIndex = 3;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            this.btn_plus.Click += new System.EventHandler(this.btn_plus_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBar1.Location = new System.Drawing.Point(696, 2);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(104, 45);
            this.trackBar1.TabIndex = 2;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hScrollBar1.Location = new System.Drawing.Point(0, 2);
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.hScrollBar1.Size = new System.Drawing.Size(693, 19);
            this.hScrollBar1.TabIndex = 1;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.TSL_status);
            this.panel2.Controls.Add(this.axKHOpenAPI1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 592);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(891, 25);
            this.panel2.TabIndex = 2;
            // 
            // TSL_status
            // 
            this.TSL_status.AutoSize = true;
            this.TSL_status.Location = new System.Drawing.Point(7, 7);
            this.TSL_status.Name = "TSL_status";
            this.TSL_status.Size = new System.Drawing.Size(57, 12);
            this.TSL_status.TabIndex = 1;
            this.TSL_status.Text = "종목 상태";
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(829, 3);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(58, 20);
            this.axKHOpenAPI1.TabIndex = 0;
            this.axKHOpenAPI1.Visible = false;
            this.axKHOpenAPI1.OnReceiveTrData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEventHandler(this.axKHOpenAPI1_OnReceiveTrData);
            this.axKHOpenAPI1.OnReceiveRealData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEventHandler(this.axKHOpenAPI1_OnReceiveRealData);
            this.axKHOpenAPI1.OnReceiveMsg += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEventHandler(this.axKHOpenAPI1_OnReceiveMsg);
            this.axKHOpenAPI1.OnReceiveChejanData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEventHandler(this.axKHOpenAPI1_OnReceiveChejanData);
            this.axKHOpenAPI1.OnEventConnect += new AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEventHandler(this.axKHOpenAPI1_OnEventConnect);
            this.axKHOpenAPI1.OnReceiveInvestRealData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveInvestRealDataEventHandler(this.axKHOpenAPI1_OnReceiveInvestRealData);
            this.axKHOpenAPI1.OnReceiveRealCondition += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealConditionEventHandler(this.axKHOpenAPI1_OnReceiveRealCondition);
            this.axKHOpenAPI1.OnReceiveTrCondition += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrConditionEventHandler(this.axKHOpenAPI1_OnReceiveTrCondition);
            this.axKHOpenAPI1.OnReceiveConditionVer += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveConditionVerEventHandler(this.axKHOpenAPI1_OnReceiveConditionVer);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(891, 25);
            this.panel1.TabIndex = 1;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.la_codeName,
            this.toolStripLabel3_code,
            this.la_currentVal,
            this.laupdawon,
            this.la_volume,
            this.toolStripLabel1,
            this.TSBday,
            this.TSBweek,
            this.TSBmonth,
            this.TSBmin,
            this.TSBtick,
            this.toolStripLabel2,
            this.TSL_su_1,
            this.TSL_su_3,
            this.TSL_su_5,
            this.TSL_su_10,
            this.TSL_su_30,
            this.TSL_su_60,
            this.TSL_su_120,
            this.toolStripLabel3,
            this.TSL_btnNext,
            this.toolStripLabel4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(891, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // la_codeName
            // 
            this.la_codeName.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.la_codeName.Name = "la_codeName";
            this.la_codeName.Size = new System.Drawing.Size(74, 22);
            this.la_codeName.Text = "종목이름";
            // 
            // toolStripLabel3_code
            // 
            this.toolStripLabel3_code.Font = new System.Drawing.Font("맑은 고딕", 8F);
            this.toolStripLabel3_code.Name = "toolStripLabel3_code";
            this.toolStripLabel3_code.Size = new System.Drawing.Size(32, 22);
            this.toolStripLabel3_code.Text = "code";
            this.toolStripLabel3_code.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // la_currentVal
            // 
            this.la_currentVal.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.la_currentVal.Name = "la_currentVal";
            this.la_currentVal.Size = new System.Drawing.Size(58, 22);
            this.la_currentVal.Text = "현재가";
            // 
            // laupdawon
            // 
            this.laupdawon.Name = "laupdawon";
            this.laupdawon.Size = new System.Drawing.Size(43, 22);
            this.laupdawon.Text = "등락률";
            // 
            // la_volume
            // 
            this.la_volume.Name = "la_volume";
            this.la_volume.Size = new System.Drawing.Size(67, 22);
            this.la_volume.Text = "누적거래량";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(15, 22);
            this.toolStripLabel1.Text = "  ";
            // 
            // TSBday
            // 
            this.TSBday.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TSBday.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSBday.Image = ((System.Drawing.Image)(resources.GetObject("TSBday.Image")));
            this.TSBday.ImageTransparentColor = System.Drawing.Color.Red;
            this.TSBday.Name = "TSBday";
            this.TSBday.Padding = new System.Windows.Forms.Padding(1);
            this.TSBday.Size = new System.Drawing.Size(25, 22);
            this.TSBday.Text = "일";
            this.TSBday.Click += new System.EventHandler(this.TSBday_Click);
            // 
            // TSBweek
            // 
            this.TSBweek.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TSBweek.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSBweek.Image = ((System.Drawing.Image)(resources.GetObject("TSBweek.Image")));
            this.TSBweek.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBweek.Name = "TSBweek";
            this.TSBweek.Padding = new System.Windows.Forms.Padding(1);
            this.TSBweek.Size = new System.Drawing.Size(25, 22);
            this.TSBweek.Text = "주";
            this.TSBweek.Click += new System.EventHandler(this.TSBweek_Click);
            // 
            // TSBmonth
            // 
            this.TSBmonth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TSBmonth.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSBmonth.Image = ((System.Drawing.Image)(resources.GetObject("TSBmonth.Image")));
            this.TSBmonth.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBmonth.Name = "TSBmonth";
            this.TSBmonth.Padding = new System.Windows.Forms.Padding(1);
            this.TSBmonth.Size = new System.Drawing.Size(25, 22);
            this.TSBmonth.Text = "월";
            this.TSBmonth.Click += new System.EventHandler(this.TSBmonth_Click);
            // 
            // TSBmin
            // 
            this.TSBmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TSBmin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSBmin.Image = ((System.Drawing.Image)(resources.GetObject("TSBmin.Image")));
            this.TSBmin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBmin.Name = "TSBmin";
            this.TSBmin.Padding = new System.Windows.Forms.Padding(1);
            this.TSBmin.Size = new System.Drawing.Size(25, 22);
            this.TSBmin.Text = "분";
            this.TSBmin.Click += new System.EventHandler(this.TSBmin_Click);
            // 
            // TSBtick
            // 
            this.TSBtick.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TSBtick.Checked = true;
            this.TSBtick.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TSBtick.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSBtick.Image = ((System.Drawing.Image)(resources.GetObject("TSBtick.Image")));
            this.TSBtick.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSBtick.Name = "TSBtick";
            this.TSBtick.Padding = new System.Windows.Forms.Padding(1);
            this.TSBtick.Size = new System.Drawing.Size(25, 22);
            this.TSBtick.Text = "틱";
            this.TSBtick.Click += new System.EventHandler(this.TSBtick_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(15, 22);
            this.toolStripLabel2.Text = "  ";
            // 
            // TSL_su_1
            // 
            this.TSL_su_1.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_1.Checked = true;
            this.TSL_su_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TSL_su_1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_1.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_1.Image")));
            this.TSL_su_1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_1.Name = "TSL_su_1";
            this.TSL_su_1.Size = new System.Drawing.Size(23, 22);
            this.TSL_su_1.Text = "1";
            this.TSL_su_1.Click += new System.EventHandler(this.TSL_su_1_Click);
            // 
            // TSL_su_3
            // 
            this.TSL_su_3.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_3.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_3.Image")));
            this.TSL_su_3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_3.Name = "TSL_su_3";
            this.TSL_su_3.Size = new System.Drawing.Size(23, 22);
            this.TSL_su_3.Text = "3";
            this.TSL_su_3.Click += new System.EventHandler(this.TSL_su_3_Click);
            // 
            // TSL_su_5
            // 
            this.TSL_su_5.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_5.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_5.Image")));
            this.TSL_su_5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_5.Name = "TSL_su_5";
            this.TSL_su_5.Size = new System.Drawing.Size(23, 22);
            this.TSL_su_5.Text = "5";
            this.TSL_su_5.Click += new System.EventHandler(this.TSL_su_5_Click);
            // 
            // TSL_su_10
            // 
            this.TSL_su_10.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_10.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_10.Image")));
            this.TSL_su_10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_10.Name = "TSL_su_10";
            this.TSL_su_10.Size = new System.Drawing.Size(25, 22);
            this.TSL_su_10.Text = "10";
            this.TSL_su_10.Click += new System.EventHandler(this.TSL_su_10_Click);
            // 
            // TSL_su_30
            // 
            this.TSL_su_30.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_30.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_30.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_30.Image")));
            this.TSL_su_30.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_30.Name = "TSL_su_30";
            this.TSL_su_30.Size = new System.Drawing.Size(25, 22);
            this.TSL_su_30.Text = "30";
            this.TSL_su_30.Click += new System.EventHandler(this.TSL_su_30_Click);
            // 
            // TSL_su_60
            // 
            this.TSL_su_60.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_60.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_60.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_60.Image")));
            this.TSL_su_60.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_60.Name = "TSL_su_60";
            this.TSL_su_60.Size = new System.Drawing.Size(25, 22);
            this.TSL_su_60.Text = "60";
            this.TSL_su_60.Click += new System.EventHandler(this.TSL_su_60_Click);
            // 
            // TSL_su_120
            // 
            this.TSL_su_120.BackColor = System.Drawing.Color.AliceBlue;
            this.TSL_su_120.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_su_120.Image = ((System.Drawing.Image)(resources.GetObject("TSL_su_120.Image")));
            this.TSL_su_120.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_su_120.Name = "TSL_su_120";
            this.TSL_su_120.Size = new System.Drawing.Size(32, 22);
            this.TSL_su_120.Text = "120";
            this.TSL_su_120.Click += new System.EventHandler(this.TSL_su_120_Click);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(19, 22);
            this.toolStripLabel3.Text = "   ";
            // 
            // TSL_btnNext
            // 
            this.TSL_btnNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TSL_btnNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TSL_btnNext.Name = "TSL_btnNext";
            this.TSL_btnNext.Size = new System.Drawing.Size(51, 22);
            this.TSL_btnNext.Text = "다음 ▶";
            this.TSL_btnNext.Click += new System.EventHandler(this.TSL_btnNext_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 24);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1143, 1);
            this.panel4.TabIndex = 2;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.Black;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabelLogin});
            this.statusStrip1.Location = new System.Drawing.Point(0, 641);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1143, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.AutoSize = false;
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Black;
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.Yellow;
            this.toolStripStatusLabel1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(700, 17);
            this.toolStripStatusLabel1.Text = "massage";
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabelLogin
            // 
            this.toolStripStatusLabelLogin.BackColor = System.Drawing.Color.Black;
            this.toolStripStatusLabelLogin.ForeColor = System.Drawing.Color.Lime;
            this.toolStripStatusLabelLogin.Name = "toolStripStatusLabelLogin";
            this.toolStripStatusLabelLogin.Size = new System.Drawing.Size(119, 17);
            this.toolStripStatusLabelLogin.Text = "로그인이 필요합니다";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(88, 22);
            this.toolStripLabel4.Text = "toolStripLabel4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(67)))), ((int)(((byte)(67)))));
            this.ClientSize = new System.Drawing.Size(1143, 663);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "키움증권 API 주식 프로그램 by 히포차트";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_upper)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ToolStripMenuItem kiwoomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Button btnNowVal;
        private System.Windows.Forms.TextBox txtRealData;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel la_codeName;
        private System.Windows.Forms.ToolStripLabel la_currentVal;
        private System.Windows.Forms.ToolStripLabel laupdawon;
        private System.Windows.Forms.ToolStripLabel la_volume;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem favordeleToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem duceToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TSBday;
        private System.Windows.Forms.ToolStripButton TSBweek;
        private System.Windows.Forms.ToolStripButton TSBmonth;
        private System.Windows.Forms.ToolStripButton TSBmin;
        private System.Windows.Forms.ToolStripButton TSBtick;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton TSL_su_1;
        private System.Windows.Forms.ToolStripButton TSL_su_3;
        private System.Windows.Forms.ToolStripButton TSL_su_5;
        private System.Windows.Forms.ToolStripButton TSL_su_10;
        private System.Windows.Forms.ToolStripButton TSL_su_30;
        private System.Windows.Forms.ToolStripButton TSL_su_60;
        private System.Windows.Forms.ToolStripButton TSL_su_120;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comAccounts;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.ComboBox comBuySellType;
        private System.Windows.Forms.ComboBox comOderType;
        private System.Windows.Forms.TextBox txtOriginalOdernumber;
        private System.Windows.Forms.TextBox txtOrderPay;
        private System.Windows.Forms.TextBox txtOrderCounts;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3_code;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLogin;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private Hippo.WindowsForm4.hHippoChart hHippoChart1;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem realsaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem nowsaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem realTextSaveGoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem mycodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripMenuItem allcodeToolStripMenuItem;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox chkSR1;
        private System.Windows.Forms.CheckBox chkSR0;
        private System.Windows.Forms.CheckBox chkBB;
        private System.Windows.Forms.CheckBox chkSR3;
        private System.Windows.Forms.CheckBox chkSR2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem conditionToolStripMenuItem;
        private System.Windows.Forms.Label TSL_status;
        private System.Windows.Forms.ToolStripButton TSL_btnNext;
        private System.Windows.Forms.ToolStripMenuItem stockmainToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem dbsaveToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkOSC;
        private System.Windows.Forms.CheckBox chkILMOK;
        private System.Windows.Forms.CheckBox chkStochastic;
        private System.Windows.Forms.CheckBox chkRSI;
        private System.Windows.Forms.ToolStripMenuItem excelsaveToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem gurewonToolStripMenuItem;
        private System.Windows.Forms.Panel pan_forin;
        private System.Windows.Forms.Panel pan_mesu;
        private System.Windows.Forms.Panel pan_medo;
        private System.Windows.Forms.DataGridView dataGridView_upper;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
    }
}


# bfx-cpp-api

_Simple static library for interfacing Bitfinex REST API_
***
BitfinexAPI depends on cryptopp and libcurl libraries. Install them before use
and don't forget to link them with your project.

See examples for general usage.

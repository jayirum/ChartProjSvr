#include "Monitor.h"



CMonitor::CMonitor()
{

}


CMonitor::~CMonitor()
{
}

void CMonitor::ThreadFunc()
{
	printf("this is thread class...");
}
#pragma once


#define	SERVICENAME		"A-Bot No1"
#define DISPNAME		"A-Bot No1"
#define DESC			"Strategy No 1"
#define EXENAME			"Abot_No1.exe"


#define __APP_VERSION "v1.0"

